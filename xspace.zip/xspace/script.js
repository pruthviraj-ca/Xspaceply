document.addEventListener("DOMContentLoaded", () => {
    const carousel = document.querySelector(".product-carousel");
    const products = document.querySelectorAll(".product-card");
    const totalProducts = products.length;
    const productsToShow = 3;
    const maxIndex = totalProducts - productsToShow;
    let currentIndex = 0;

    function scrollCarousel() {
        const translateX = -(currentIndex * 100 / productsToShow);
        carousel.style.transform = `translateX(${translateX}%)`;
        currentIndex = (currentIndex + 1) > maxIndex ? 0 : currentIndex + 1;
    }

    setInterval(scrollCarousel, 5000);

    // Background Image Array for Hero Section
    const hero = document.querySelector(".hero");
    const backgrounds = [
        "url('bg1.jpeg')",
        "url('bg2.jpeg')",
        "url('bg3.jpeg')",
        "url('bg4.jpeg')",
        "url('bg5.jpeg')"
    ];

    let currentBackgroundIndex = 0;

    function changeBackground() {
        hero.style.backgroundImage = backgrounds[currentBackgroundIndex];
        currentBackgroundIndex = (currentBackgroundIndex + 1) % backgrounds.length;
    }

    setInterval(changeBackground, 9000);
});
document.addEventListener("DOMContentLoaded", () => {
    const contactForm = document.querySelector(".contact-form-container");
    contactForm.style.opacity = 0;
    contactForm.style.transform = "translateY(20px)";
    setTimeout(() => {
        contactForm.style.transition = "opacity 1s ease, transform 1s ease";
        contactForm.style.opacity = 1;
        contactForm.style.transform = "translateY(0)";
    }, 500);
});
document.addEventListener("DOMContentLoaded", () => {
    const cards = document.querySelectorAll(".professional-card");
    cards.forEach((card, index) => {
        card.style.opacity = "0";
        card.style.transition = "opacity 1s ease-in-out, transform 0.5s ease";
        setTimeout(() => {
            card.style.opacity = "1";
            card.style.transform = "translateY(0)";
        }, index * 300);
    });
});
